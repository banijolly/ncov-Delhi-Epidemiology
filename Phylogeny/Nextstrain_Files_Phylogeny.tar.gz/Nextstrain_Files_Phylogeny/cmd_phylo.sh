snakemake --cores 6 --profile my_profiles/example
