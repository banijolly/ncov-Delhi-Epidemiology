# Glossary  

#### Alignment  

#### Ancestral trait (reconstruction)  

#### Augur  

#### Auspice  

#### Bases  

#### Branch  

#### Build  

#### Config  

#### Division  

#### Filtering  

#### Genome  

#### Genomic epidemiology

#### GISAID   

#### Location

#### Metadata  

#### Narrative

#### Node    

#### Phylogeny

#### Reference genome  

#### Region  

#### Sample   

#### Sequence

#### Snakemake  

#### Strain  

#### Subsampling  

#### Tip (leaf)

#### TSV    

#### Trait  

#### Transmission

#### Tree      

#### Workflow manager  
