This is the description that appears below your visualization in Auspice. Edit me in `my_profiles/example/description.md`.
